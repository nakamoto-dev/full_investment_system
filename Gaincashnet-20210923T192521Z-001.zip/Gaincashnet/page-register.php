<?php
    ob_start();
    include "./db/dbconn.php";
    session_start();
    include "./utils/otpGen.php";
    include "./Mails/send.php";
?>




<!DOCTYPE html>
<html lang="en" class="h-100">


<!-- Mirrored from dompet.dexignlab.com/xhtml/page-register.html by HTTrack Website Copier/3.x [XR&CO'2014], Wed, 07 Jul 2021 05:51:55 GMT -->
<head>
    <meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="keywords" content="" />
	<meta name="author" content="" />
	<meta name="robots" content="" />
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<meta name="description" content="Dompet : Payment Admin Template" />
	<meta property="og:title" content="Dompet : Payment Admin Template" />
	<meta property="og:description" content="Dompet : Payment Admin Template" />
	<meta property="og:image" content="social-image.png" />
	<meta name="format-detection" content="telephone=no">

	<!-- PAGE TITLE HERE -->
	<title>Dompet : Payment Admin Template</title>

	<!-- FAVICONS ICON -->
	<link rel="shortcut icon" type="image/png" href="images/favicon.png" />
    <link href="css/style.css" rel="stylesheet">

</head>

<body class="vh-100">
    <div class="authincation h-100">
        <div class="container h-100">
            <div class="row justify-content-center h-100 align-items-center">
                <div class="col-md-6">
                    <div class="authincation-content">
                        <div class="row no-gutters">
                            <div class="col-xl-12">
                                <div class="auth-form">
									<div class="text-center mb-3">
										<a href="index.html"><img src="images/logo-full.png" alt=""></a>
									</div>
                                    <h4 class="text-center mb-4">Sign up your account</h4>
                                    <form action="
                                    <?php
                                    if(isset($_GET['u_id'])&&isset($_GET['u_name'])){
                                      echo "page-register.php?u_id=".$_GET['u_id']."&u_name=".$_GET['u_name'];
                                    }else{
                                      echo"page-register.php";
                                    }
                                    ?>
                                      " method="post">
                                        <div class="mb-3">
                                            <label class="mb-1"><strong>Username</strong></label>
                                            <input type="text" name="username" class="form-control" placeholder="username">
                                        </div>
                                        <div class="mb-3">
                                            <label class="mb-1"><strong>Email</strong></label>
                                            <input type="email" name="email" class="form-control" placeholder="hello@example.com">
                                        </div>
                                        <div class="mb-3">
                                            <label class="mb-1"><strong>phone</strong></label>
                                            <input type="text" name="phone" class="form-control" placeholder="phone">
                                        </div>
                                        <div class="mb-3">
                                            <label class="mb-1"><strong>Password</strong></label>
                                            <input type="password" name="password" class="form-control" placeholder="Password">
                                        </div>
                                        <div class="text-center mt-4">
                                            <button type="submit" name="submit" class="btn btn-primary btn-block">Sign me up</button>
                                        </div>
                                    </form>
                                    <div class="new-account mt-3">
                                        <p>Already have an account? <a class="text-primary" href="page-login.html">Sign in</a></p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

<!--**********************************
	Scripts
***********************************-->
<!-- Required vendors -->
<script src="vendor/global/global.min.js"></script>
<script src="js/custom.min.js"></script>
<script src="js/dlabnav-init.js"></script>
<script src="js/styleSwitcher.js"></script>
<script src="js/sweetalert.min.js"></script>
<?php
    if(isset($_POST['submit'])){
        $username = mysqli_real_escape_string($conn,$_POST['username']);
        $email = mysqli_real_escape_string($conn,$_POST['email']);
        $password =mysqli_real_escape_string($conn,$_POST['password']);
        $phone = mysqli_real_escape_string($conn,$_POST['phone']);
        if(empty($username)||empty($email)||empty($password)||empty($phone)){ ?>
            <script>
                swal({
                    title: "Oops!",
                    text: "All fields must be filled",
                    icon: "error",
                    button: "Adjust",
                });
            </script>
        <?php }else{

        $usersU_nameinDbQuery = "SELECT * FROM `users` WHERE `username` = '$username'";
        $usersU_nameinDbQueryResult = mysqli_query($conn,$usersU_nameinDbQuery);
        echo mysqli_num_rows($usersU_nameinDbQueryResult);
          if(mysqli_num_rows($usersU_nameinDbQueryResult)>0){
            ?>
                <script>
                    swal({
                        title: "Oops!",
                        text: "Username Exists",
                        icon: "error",
                        button: "Adjust",
                    });
                </script>
            <?php
          }
          $usersemailinDbQuery = "SELECT * FROM `users` WHERE `email` = '$email'";
          $usersemailinDbQueryResult = mysqli_query($conn,$usersemailinDbQuery);
          echo mysqli_num_rows($usersemailinDbQueryResult);
          if(mysqli_num_rows($usersemailinDbQueryResult)>0){
            ?>
                <script>
                    swal({
                        title: "Oops!",
                        text: "email Exists",
                        icon: "error",
                        button: "Adjust",
                    });
                </script>
            <?php
          }
          $usersPhoneinDbQuery = "SELECT * FROM `users` WHERE `phone` = '$phone'";
          $usersPhoneinDbQueryResult = mysqli_query($conn,$usersPhoneinDbQuery);
          echo mysqli_num_rows($usersPhoneinDbQueryResult);
          if(mysqli_num_rows($usersPhoneinDbQueryResult)>0){
            ?>
                <script>
                    swal({
                        title: "Oops!",
                        text: "Phone Exists",
                        icon: "error",
                        button: "Adjust",
                    });
                </script>
            <?php
          }
          if((mysqli_num_rows($usersU_nameinDbQueryResult) ==0)&&(mysqli_num_rows($usersemailinDbQueryResult)==0)&&(mysqli_num_rows($usersPhoneinDbQueryResult)==0)){
           $hashfomat = "$2y$10$";
           $salt = "iusesomecrazystrings22";
           $hash_salt = $hashfomat.$salt;
           $password = crypt($password,$hash_salt);
           //otp
           $otp = getOtp();
           if(isset($_GET['u_id'])&&isset($_GET['u_name'])){
             echo"strng";
             if(empty($_GET['u_id'])||empty($_GET['u_name'])){
               ?>
               <script>
               swal({
                   title: "Oops",
                   text: "invitation link is invalid",
                   icon: "error",
                   button: "Retry!",
               });
              </script>

     <?php
             }
             $uplineId = mysqli_real_escape_string($conn,$_GET['u_id']);
             $uplineU_name =mysqli_real_escape_string($conn,$_GET['u_name']);
             $uplineUserQuery = "SELECT * FROM `users` WHERE `id`='$uplineId' AND `username`='$uplineU_name'";
             $uplineUserResults = mysqli_query($conn,$uplineUserQuery);
             if(!$uplineUserResults){
               die("Error ".mysqli_error($conn));
             }
             $userLength = mysqli_num_rows($uplineUserResults);
             if($userLength == 0 ){
               ?>
               <script>
               swal({
                   title: "Opps",
                   text: "The invitation link is not valid",
                   icon: "error",
                   button: "Retry!",
               });
              </script>

     <?php

             }
             foreach($uplineUserResults as $upline_u){
             $uplineEmail = $upline_u['email'];
             echo $uplineEmail;
             $referalQuery="INSERT INTO `referals`(`upline_id`, `upline_email`, `downline_email`) VALUES ('$uplineId','$uplineEmail','$email')";
             $referalResults = mysqli_query($conn,$referalQuery);
             if(! $referalResults){
               die(mysqli_error($conn));
             }
           }
           }
           //query

           $query = "INSERT INTO `users`(`username`, `phone`, `email`, `password`, `date`, `otp`) VALUES ('$username','$phone','$email','$password',now(),'$otp')";
           $result = mysqli_query($conn,$query);

           if(!$result){
            die("error:" .mysqli_error($conn));
           }else{
             $msg='<h1> Welcome To GainCashNet.com</h1>
             <P>Your verification code is '.$otp.'</P>';
             sendMail($email,$username,$msg);
              $_SESSION['username'] = $username;
              $_SESSION['email'] = $email;
              $_SESSION['phone'] = $phone;
              $_SESSION['otpsesh'] = "go to otp";
             header("Location: otp.php");
       }

        }
   }
 }
?>
</body>

<!-- Mirrored from dompet.dexignlab.com/xhtml/page-register.html by HTTrack Website Copier/3.x [XR&CO'2014], Wed, 07 Jul 2021 05:51:55 GMT -->
</html>
