<?php
include "./includes/header.php";
$data = json_decode(file_get_contents("php://input"), TRUE);
$winning = $data['winning'];
$prize =$winning['text'];
$username = $userSession['username'];
$insertSpinInstance = "INSERT INTO `spinnerearnings`(`user_id`, `username`, `amountin`, `amountout`, `date`) VALUES ('$userid','$username',50,100,now())";
$insertSpinInstanceResult = mysqli_query($conn,$insertSpinInstance);
if(!$insertSpinInstanceResult){
  die("Error: ".mysqli_error($conn));
}
echo "success";
?>
