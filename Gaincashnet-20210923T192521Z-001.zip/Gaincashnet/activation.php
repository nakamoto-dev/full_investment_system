<?php
    ob_start();
    include "./db/dbconn.php";
    include "./utils/walletid.php";
    session_start();
    if(!isset($_SESSION['otpsesh'])){
      header("Location: page-login.php");
    }
?>


<!DOCTYPE html>
<html lang="en" class="h-100">


<!-- Mirrored from dompet.dexignlab.com/xhtml/page-lock-screen.html by HTTrack Website Copier/3.x [XR&CO'2014], Wed, 07 Jul 2021 05:51:56 GMT -->
<head>
    <meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="keywords" content="" />
	<meta name="author" content="" />
	<meta name="robots" content="" />
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<meta name="description" content="Dompet : Payment Admin Template" />
	<meta property="og:title" content="Dompet : Payment Admin Template" />
	<meta property="og:description" content="Dompet : Payment Admin Template" />
	<meta property="og:image" content="social-image.png" />
	<meta name="format-detection" content="telephone=no">

	<!-- PAGE TITLE HERE -->
	<title>Dompet : Payment Admin Template</title>

	<!-- FAVICONS ICON -->
	<link rel="shortcut icon" type="image/png" href="images/favicon.png" />
    <link href="css/style.css" rel="stylesheet">

</head>

<body class="vh-100">
    <div class="authincation h-100">
        <div class="container h-100">
            <div class="row justify-content-center h-100 align-items-center">
                <div class="col-md-6">
                    <div class="authincation-content">
                        <div class="row no-gutters">
                            <div class="col-xl-12">
                                <div class="auth-form">
									<div class="text-center mb-3">
										<a href="index.html"><img src="images/logo-full.png" alt=""></a>
									</div>
                                    <h4 class="text-center mb-4">Activate  Account</h4>
                                    <h4 class="text-center mb-4">Please use the 254 format(note  dont use ()+))</h4>
                                    <form action="otp.php" method="POST">
                                        <div class="mb-3">
                                            <label><strong>PHONE</strong></label>
                                            <input type="number" name="phone" class="form-control" placeholder="254704809536">
                                        </div>
                                        <div class="mb-3">
                                            <label><strong>Amount</strong></label>
                                            <input type="text" name="amount" class="form-control" value="1000">
                                        </div>
                                        <div class="text-center">
                                            <button type="submit" name="submit" class="btn btn-primary btn-block">Submit</button>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <!-- #/ container -->
    <!-- Common JS -->
    <script src="vendor/global/global.min.js"></script>
    <!-- Custom script -->
    <script src="vendor/dlabnav/dlabnav.min.js"></script>
    <script src="js/custom.min.js"></script>
    <script src="js/dlabnav-init.js"></script>
	<script src="js/styleSwitcher.js"></script>
    <script src="js/sweetalert.min.js"></script>
    <?php
    if(isset($_SESSION['otpsesh'])){
      ?>
      <script>
      swal({
          title: "Good Work",
          text: "Welcome on board you have successfully registered",
          icon: "success",
          button: "Go!",
      });
     </script>

<?php
    }

        if(isset($_POST["submit"])){
          $userEmail = $_SESSION['email'];
          $userOtp = mysqli_real_escape_string($conn,$_POST['otp']);
          if(empty($userOtp)){
            ?>
            <script>
            swal({
                title: "Sorry",
                text: "Otp cannot be empty",
                icon: "error",
                button: "Retry!",
            });
           </script>

  <?php
          }
          $otpQuery = "SELECT * FROM `users` WHERE `email` = '$userEmail'";
          $userOtpQueryReslts = mysqli_query($conn,$otpQuery);
          if(!$userOtpQueryReslts){
            die("Erro: " .mysqli_error($conn));
          }
          foreach ($userOtpQueryReslts as $result) {
            // code...
            $dbOtp = $result['otp'];
            // echo $dbOtp;
            if($userOtp == $dbOtp){
              $updateQuery = "UPDATE `users` SET `emailConfirmation`=1 WHERE `email` = '$userEmail'";
              $updateQueryResults = mysqli_query($conn,$updateQuery);
              if(!$updateQueryResults){
                die ("Error : ".mysqli_error($conn));
              }
              $userInReferal = "SELECT * FROM `referals` WHERE `downline_email`='$userEmail'";
              $userInReferalResults = mysqli_query($conn,$userInReferal);
              echo $userEmail;
              echo (mysqli_num_rows($userInReferalResults));
              if(mysqli_num_rows($userInReferalResults)>0){
                  foreach($userInReferalResults as $result){
                    $uplineId = $result['upline_id'];
                    $uplineEmail = $result['upline_email'];
                    $uplineRefrenceQuery = "SELECT * FROM `referals` WHERE `upline_id`='$uplineId' AND `upline_email`='$uplineEmail'";
                    $uplineRefrenceQueryResults = mysqli_query($conn,$uplineRefrenceQuery);
                    $totalDownlines = mysqli_num_rows($uplineRefrenceQueryResults);
                    $referalUpdateQuery = "UPDATE `users` SET `invites`='$totalDownlines' WHERE `email`='$uplineEmail' ";
                    $referalUpdateQueryresults = mysqli_query($conn,$referalUpdateQuery);
                    if(!$referalUpdateQueryresults){
                      die("Error :".mysqli_error($conn));
                    }
                  }
              }
              $walletId = generateRandomString();
              $resultid = $result['id'];
              $resultname = $result['username'];
              $saccoquery = "INSERT INTO `sacco`(`user_id`, `username`,`validUntil`,`wallet_id`) VALUES ('$resultid','$resultname',now(),'$walletId')";
              $saccoresult = mysqlI_query($conn,$saccoquery);
              if(!$saccoresult){
                die('error: '.mysqli_error($conn));
              }
              $_SESSION['email']=  $userEmail;
              $_SESSION['otpsesh'] = null;
              $_SESSION["successOtp"] = "OK Otp";
              header("Location: index.php");
            }else{
              ?>
              <script>
              swal({
                  title: "Oops",
                  text: "Wrong Otp",
                  icon: "error",
                  button: "Retry!",
              });
             </script>

    <?php
            }
          }
        }

    ?>
</body>

<!-- Mirrored from dompet.dexignlab.com/xhtml/page-lock-screen.html by HTTrack Website Copier/3.x [XR&CO'2014], Wed, 07 Jul 2021 05:51:57 GMT -->
</html>
