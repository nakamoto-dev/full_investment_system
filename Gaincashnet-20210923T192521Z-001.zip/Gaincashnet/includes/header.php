<?php
ob_start();
include "./db/dbconn.php";
session_start();
?>

<?php
  if(!isset($_SESSION['email'])){
    header("Location: page-login.php");
  }
  $userEmail = $_SESSION['email'];
  $query = "SELECT * FROM `users` WHERE `email`='$userEmail'";
  $results= mysqlI_query($conn,$query);
  if(!$results){
    die("Error: ".mysqli_error($conn));
  }
  foreach ($results as $result) {
    // code...
    $_SESSION ['user'] = $result;
  }


?>

<!DOCTYPE html>
<html lang="en">

<!-- Mirrored from dompet.dexignlab.com/xhtml/index-2.html by HTTrack Website Copier/3.x [XR&CO'2014], Wed, 07 Jul 2021 05:45:06 GMT -->
<head>

    <meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="keywords" content="" />
	<meta name="author" content="" />
	<meta name="robots" content="" />
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<meta name="description" content="Dompet : Payment Admin Template" />
	<meta property="og:title" content="Dompet : Payment Admin Template" />
	<meta property="og:description" content="Dompet : Payment Admin Template" />
	<meta property="og:image" content="social-image.png" />
	<meta name="format-detection" content="telephone=no">

	<!-- PAGE TITLE HERE -->
	<title>Dompet : Payment Admin Template</title>

	<!-- FAVICONS ICON -->

	<link rel="shortcut icon" type="image/png" href="images/favicon.png" />

	<link href="vendor/jquery-nice-select/css/nice-select.css" rel="stylesheet">
	<link rel="stylesheet" href="vendor/nouislider/nouislider.min.css">
	<!-- Style css -->
    <link href="css/style.css" rel="stylesheet">
    <link href='spininstance/spin/main.css'rel="stylesheet">
    <link href="vendor/owl-carousel/owl.carousel.css" rel="stylesheet">
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.15.3/css/all.css"
    integrity="sha384-SZXxX4whJ79/gErwcOYf+zWLeJdY/qpuqC4cAa9rOGUstPomtqpuNWT9wdPEn2fk" crossorigin="anonymous">
    <script type="text/javascript" src="./Winwheel.js"></script>
    <script src="http://cdnjs.cloudflare.com/ajax/libs/gsap/latest/TweenMax.min.js"></script>
</head>

<body>
  <?php
  $userSession=$_SESSION['user'];
  $userid = $userSession['id'];
  $saccoquery = "SELECT * FROM `sacco` WHERE `user_id` ='$userid'";
  $saccoResults = mysqlI_query($conn,$saccoquery);
  if(!$saccoResults){
    die("Error: ".mysqli_error($conn));
  }
  foreach ($saccoResults as $saccoresult) {
    // code...
    $_SESSION['saccoUser'] = $saccoresult;
  }
  $saccoUserSession = $_SESSION['saccoUser'];
?>
