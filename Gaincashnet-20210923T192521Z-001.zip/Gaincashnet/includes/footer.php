<div class="footer">

  <div class="copyright">
    <p>Copyright © Designed &amp; Developed by <a href="https://dexignlab.com/" target="_blank">DexignLab</a> 2021
    </p>
  </div>
</div>
<!--**********************************
        Footer end
    ***********************************-->

<!--**********************************
       Support ticket button start
    ***********************************-->

<!--**********************************
       Support ticket button end
    ***********************************-->


</div>
<!--**********************************
    Main wrapper end
***********************************-->

<!--**********************************
    Scripts
***********************************-->
<!-- Required vendors -->
<script src="vendor/global/global.min.js"></script>
<script src="vendor/chart.js/Chart.bundle.min.js"></script>
<script src="vendor/jquery-nice-select/js/jquery.nice-select.min.js"></script>

<!-- Apex Chart -->
<script src="vendor/apexchart/apexchart.js"></script>
<script src="vendor/nouislider/nouislider.min.js"></script>
<script src="vendor/wnumb/wNumb.js"></script>

<!-- Dashboard 1 -->
<script src="js/dashboard/dashboard-1.js"></script>

<script src="js/custom.min.js"></script>
<script src="js/dlabnav-init.js"></script>
<script src="js/demo.js"></script>
<script src="js/styleSwitcher.js"></script>
<script>
jQuery(document).ready(function () {
  setTimeout(function () {
    dezSettingsOptions.version = 'dark';
    new dezSettings(dezSettingsOptions);
  }, 500)
});
</script>
<?php
  if(isset($_SESSION["successOtp"])){
    $_SESSION["successOtp"]=null;
    ?>
    <script>
    swal({
        title: "Lets Go!",
        text: "welcome to the community please activate your account with 1000ksh",
        icon: "success",
        button: "Activate!",
    });
   </script>

<?php
  }
?>
</body>

<!-- Mirrored from dompet.dexignlab.com/xhtml/index-2.html by HTTrack Website Copier/3.x [XR&CO'2014], Wed, 07 Jul 2021 05:47:40 GMT -->

</html>
