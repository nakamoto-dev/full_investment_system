<?php 
	function getOtp (){
	$digits = 4;
    $otp = rand(pow(10, $digits-1), pow(10, $digits)-1);
    return $otp;
	}
	
?>