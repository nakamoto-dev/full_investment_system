<?php
function dueDate(){
  $x = 7; //number of days in the past

 $past_stamp = time() + $x*24*60*60;

 $past_date = date('Y-m-d', $past_stamp);
return $past_date;
}
?>
