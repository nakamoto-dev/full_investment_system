<?php
ob_start();
include "./includes/header.php";
include "./utils/dueDate.php";
  if(isset($_SESSION['saccoUser'])){
    $ses = $_SESSION['saccoUser'];
    $userid = $ses['user_id'];
    $idd = $ses['id'];
    echo $userid ;
    $saccoquery = "SELECT * FROM `sacco` WHERE `user_id` ='$userid' ";
    $saccoResults = mysqli_query($conn,$saccoquery);
    if(!$saccoResults){
      die("Error: ".mysqli_error($conn));
    }
    foreach ($saccoResults as $saccoresult) {
      // code...
      print_r($saccoresult);
      $bal = $saccoresult ['balance'];
      $profit = $bal * 2;
      $duedate = dueDate();echo"het";
      $updatequery = "UPDATE `sacco` SET `balance`=0, `profit`='$profit', `validUntil`='$duedate' WHERE `id` = '$idd' ";
      echo $updatequery;
      $reulstQuery = mysqli_query($conn , $updatequery);
      if(!$reulstQuery){
        die("mrror: ".mysqli_error($conn) );
      }
      echo hey;
      header("Location: my-wallet.php");
    }

  }else{
    header("Location: page-login.php" );
  }
?>
